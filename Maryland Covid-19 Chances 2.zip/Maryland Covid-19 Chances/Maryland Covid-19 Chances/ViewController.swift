//
//  ViewController.swift
//  Maryland Covid-19 Chances
//
//  Created by devs on 10/12/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

