//
//  MainViewController.swift
//  Maryland Covid-19 Chances
//
//  Created by devs on 10/31/20.
//

import UIKit

class MainViewController: UIViewController {

    //CONNECTIONS
    


    //QUESTIONS
    @IBOutlet weak var favoriteDayTextField: UITextField!
    @IBOutlet weak var ageTextField: UITextField!
    @IBOutlet weak var yesOrNo: UITextField!
    @IBOutlet weak var AroundPeople: UITextField!
    @IBOutlet weak var historyWithFlu1: UITextField!
    @IBOutlet weak var highBloodPessure1: UITextField!
    @IBOutlet weak var immuneSystem1: UITextField!
    @IBOutlet weak var drugUse1: UITextField!
    
    @IBOutlet weak var infoTrack: UILabel!
    @IBOutlet weak var infoTrack1: UILabel!
    @IBOutlet weak var introTrack2: UILabel!
    @IBOutlet weak var introTrack3: UILabel!
    @IBOutlet weak var introTrack4: UILabel!
    @IBOutlet weak var introTrack5: UILabel!
    @IBOutlet weak var introTrack6: UILabel!
    @IBOutlet weak var introTrack7: UILabel!
    
    @IBOutlet weak var percent: UILabel!
    
    @IBOutlet weak var box1: UIButton!

    @IBOutlet weak var questions: UILabel!
    
    @IBOutlet weak var nextResults: UIButton!
    @IBOutlet weak var backResult2: UIButton!
    
    
    //VARIABLES

    
    //Questions answers
    var results3: Float = 0.0
    var percentage: Float = 0.0
    var age: Float = 0.0
    var results: Float = 0.0
    var Yes1: Float = 1.0
    var No1: Float = 1.0
    var already: Float = 20
    var questionPoint = 0.0
    
    var results2: Float = 0.0
    var hwf: Float = 0.0
    var highBoodPress: Float = 0.0
    var immuneSys: Float = 0.0
    var drugUsage: Float = 0.0
    var hwf2: Float = 0.0
    var highBoodPress2: Float = 0.0
    var immuneSys2: Float = 0.0
    var drugUsage2: Float = 0.0
    var Yes2: Float = 0.5
    var firstBox: Bool = false;

    

 
    
    
    //DECIMALS
    
    var formatter = NumberFormatter()
    //GET RESULTS
  
    
    //MORE CONNECTIONS
    

    
    //SEGMENT CONTROL STUFF
    
  

  
        
        
        

    
    


//WHEN YOU CLICK NEXT / GET RESULTS

    @IBAction func getResults(_ sender: UIButton) {
   
//ADD ONE
        questionPoint = (questionPoint + 1)
    
       
       
    
        print(questionPoint)
         
        //MORE THAN 8 SUBTRACT BY 1
        if questionPoint > 8 {
            
            questionPoint = (questionPoint - 1)
        }
        
//IF FIRSTBOX IS FALSE DONT LET IT SKIP
        if firstBox == Bool(false) {
            
            print("Answer Question")
        questionPoint = (questionPoint - 1)
          
            
        box1.isHidden = false
    
    } else {
        
        box1.isHidden = true
    
        }

        
        
        if questionPoint == 1 {
        questions.text! = "Select Age"
            firstBox = Bool(false)
            ageTextField.isHidden = false
            favoriteDayTextField.isHidden = true
            nextResults.setTitle("Next", for: .normal)
            backResult2.setTitle("Back", for: .normal)
            backResult2.isHidden = false
            print(firstBox)
       
            
            if infoTrack1.text! == "65 - 100" {
                firstBox = Bool(true)
 
            }
 
            if infoTrack1.text! == "50 - 64" {
                firstBox = Bool(true)
            }
            if infoTrack1.text! == "35 - 49" {
                firstBox = Bool(true)
            }
            if infoTrack1.text! == "20 - 34" {
                firstBox = Bool(true)
    }
            if infoTrack1.text! == "13 - 19" {
                firstBox = Bool(true)
            }
            if infoTrack1.text! == "3 - 12" {
                firstBox = Bool(true)
            }

            
                        
                }
        if questionPoint == 2 {
        questions.text! = "Have You Been Around People?"
       
            ageTextField.isHidden = true
            yesOrNo.isHidden = false
            firstBox = Bool(false)
            nextResults.setTitle("Next", for: .normal)
            backResult2.setTitle("Back", for: .normal)
            if introTrack2.text! == "Yes" {
                firstBox = Bool(true)
            }
            if introTrack2.text! == "No" {
                firstBox = Bool(true)
            }

                }
    
        
        
        if questionPoint == 3 {
        questions.text! = "Do you wash your hands frequently?"
            nextResults.setTitle("Next", for: .normal)
            backResult2.setTitle("Back", for: .normal)
            yesOrNo.isHidden = true
            firstBox = Bool(false)
            
            AroundPeople.isHidden = false
       
            if introTrack3.text! == "Yes" {
                firstBox = Bool(true)
            }
            if introTrack3.text! == "No" {
                firstBox = Bool(true)
            }

                
    
            
            
        }
    
            
        
        if questionPoint == 4 {
        questions.text! =  "Have you been around people with the flu"
       
            nextResults.setTitle("Next", for: .normal)
            historyWithFlu1.isHidden = false
            backResult2.setTitle("Back", for: .normal)
            firstBox = Bool(false)
            AroundPeople.isHidden = true
            
            if introTrack4.text! == "Yes" {
                firstBox = Bool(true)
            }
            if introTrack4.text! == "No" {
                firstBox = Bool(true)
            }

                
                        
                }
        if questionPoint == 5 {
        questions.text! = "Do you have a history with health problems? (Diabetes, High Blood Pressure, Cancer or Lung Disease)"
            nextResults.setTitle("Next", for: .normal)
            backResult2.setTitle("Back", for: .normal)
            firstBox = Bool(false)
            historyWithFlu1.isHidden = true
            highBloodPessure1.isHidden = false
            firstBox = Bool(false)
            
            if introTrack5.text! == "Yes" {
                firstBox = Bool(true)
            }
            if introTrack5.text! == "No" {
                firstBox = Bool(true)
            }
                              
            
        }
        if questionPoint == 6 {
        questions.text! =  "Have you been seeing symptoms? (Coughing, Fever, Sneezing, Lost sense of smell)"
            highBloodPessure1.isHidden = true
            backResult2.setTitle("Back", for: .normal)
            immuneSystem1.isHidden = false
            nextResults.setTitle("Next", for: .normal)
            firstBox = Bool(false)
            nextResults.isHidden = false
             
            if introTrack6.text! == "Yes" {
                firstBox = Bool(true)
            }
            if introTrack6.text! == "No" {
                firstBox = Bool(true)
            }
                        
                }
        
        if questionPoint == 7 {
        questions.text! =  "Have you been vaccinated?"
            backResult2.setTitle("Back", for: .normal)
            nextResults.setTitle("Get Results", for: .normal)
            firstBox = Bool(false)
            immuneSystem1.isHidden = true
            drugUse1.isHidden = false
            nextResults.isHidden = false
            
            if introTrack7.text! == "Yes" {
                firstBox = Bool(true)
            }
            if introTrack7.text! == "No" {
                firstBox = Bool(true)
            
                              
                            
                        
            }
        }
        if questionPoint == 8 {
        questions.text! =  ""
            
            backResult2.setTitle("Back", for: .normal)
            
            results = Float(0.0)
            
            firstBox = Bool(firstBox)
           
        
            //PLEASE DONT SPAM THE DECIMALS
            
            formatter.maximumFractionDigits = 2
            formatter.minimumFractionDigits = 2
            
            //WHAT I WANT IN THE RESULTS
            results = Float((percentage + age + already) * (No1) * (Yes1))
            results2 = Float((hwf + highBoodPress + drugUsage + immuneSys) + (hwf2 + highBoodPress2 + drugUsage2 + immuneSys2) * (Yes2) )
            results3 = Float(results + results2)
            
            
            //MAKE IT SO THAT IF IT CANT EQUAL OVER 100
       
            
            
            if results3 < -1 && results3 > -9 {
                print(results3)
                results3 = (results3 + 10)
                print(results3)
                
            }
            if results3 < -10 && results3 > -19 {
                print(results3)
                results3 = (results3  * -1)
                print(results3)
                
            }
            if results3 < -20 && results3 > -29 {
                print(results3)
                results3 = (results3 * -1)
                print(results3)
                
            }
            if results3 < -30 && results3 > -39 {
                print(results3)
                results3 = (results3 + 40)
                print(results3)
                
            }
            if results3 < -40 && results3 > -49 {
                print(results3)
                results3 = (results3 + 50)
                print(results3)
                
            }
            if results3 < -50 && results3 > -59 {
                print(results3)
                results3 = (results3 + 60)
                print(results3)
                
            }
            if results3 < -60 && results3 > -69 {
                print(results3)
                results3 = (results3 + 70)
                print(results3)
                
            }
            if results3 < -70 && results3 > -79 {
                print(results3)
                results3 = (results3 + 80)
                print(results3)
                
            }
            if results3 < -80 && results3 > -89 {
                print(results3)
                results3 = (results3 + 90)
                print(results3)
                
            }
            if results3 < -90 && results3 > -99 {
                print(results3)
                results3 = (results3 + 100)
                print(results3)
                
            }
            
            
            
            if results3 > 100 && results3 < 109 {
                print(results3)
                results3 = (results3 - 10)
                print(results3)
                
            }
            if results3 > 110 && results3 < 119 {
                print(results3)
                results3 = (results3 - 20)
                print(results3)
                
            }
            if results3 > 120 && results3 < 129 {
                print(results3)
                results3 = (results3 - 30)
                print(results3)
                
            }
            if results3 > 130 && results3 < 139 {
                print(results3)
                results3 = (results3 - 40)
                print(results3)
                
            }
            if results3 > 140 && results3 < 149 {
                print(results3)
                results3 = (results3 - 50)
                print(results3)
                
            }
            if results3 > 150 && results3 < 159 {
                print(results3)
                results3 = (results3 - 60)
                print(results3)
                
            }
            if results3 > 160 && results3 < 169 {
                print(results3)
                results3 = (results3 - 70)
                print(results3)
                
            }
            if results3 > 170 && results3 < 179 {
                print(results3)
                results3 = (results3 - 80)
                print(results3)
                
            }
            if results3 > 180 && results3 < 189 {
                print(results3)
                results3 = (results3 - 90)
                print(results3)
                
            }
            if results3 > 190 && results3 < 199 {
                print(results3)
                results3 = (results3 - 100)
                print(results3)
                
            }
            if results3 > 200 && results3 < 209 {
                print(results3)
                results3 = (results3 - 110)
                print(results3)
                
            }
            if results3 > 210 && results3 < 219 {
                print(results3)
                results3 = (results3 - 120)
                print(results3)
                
            }
            if results3 > 220 && results3 < 229 {
                print(results3)
                results3 = (results3 - 130)
                print(results3)
                
            }
            if results3 > 230 && results3 < 239 {
                print(results3)
                results3 = (results3 - 140)
                print(results3)
                
            }
            if results3 > 240 && results3 < 249 {
                print(results3)
                results3 = (results3 - 150)
                print(results3)
                
            }
            if results3 > 250 && results3 < 259 {
                print(results3)
                results3 = (results3 - 160)
                print(results3)
                
            }
            if results3 > 260 && results3 < 269 {
                print(results3)
                results3 = (results3 - 170)
                print(results3)
                
            }
            
            
         
            
            if let formattedString = formatter.string(for: results3) {
            
                percent.text = "\(formattedString)%"
            
              
            
            nextResults.setTitle("", for: .normal)
                nextResults.isHidden = true
            immuneSystem1.isHidden = false
            drugUse1.isHidden = false
            
            
        
           
  


    }
        
        }
    }
            
                  
  
         
    
    @IBAction func backResult(_ sender: UIButton) {
        firstBox = Bool(firstBox)
        questionPoint = (questionPoint - 1)
        print(questionPoint)
      
        if questionPoint < 0 {
            
            questionPoint = (questionPoint + 1)
            
        }
        if questionPoint == 0 {
        questions.text! = "Select County"
       
            ageTextField.isHidden = true
            yesOrNo.isHidden = true
            favoriteDayTextField.isHidden = false
            AroundPeople.isHidden = true
            historyWithFlu1.isHidden = true
            highBloodPessure1.isHidden = true
            immuneSystem1.isHidden = true
            drugUse1.isHidden = true
            firstBox = Bool(true)
            backResult2.setTitle("", for: .normal)
            backResult2.isHidden = true
            nextResults.setTitle("Next", for: .normal)
                }
        
        if questionPoint == 1 {
        questions.text! = "Select Age"
            
            ageTextField.isHidden = false
            yesOrNo.isHidden = true
            favoriteDayTextField.isHidden = true
            AroundPeople.isHidden = true
            historyWithFlu1.isHidden = true
            highBloodPessure1.isHidden = true
            immuneSystem1.isHidden = true
            drugUse1.isHidden = true
            firstBox = Bool(true)
            backResult2.setTitle("Back", for: .normal)
            backResult2.isHidden = false
            nextResults.setTitle("Next", for: .normal)
        
                }
        if questionPoint == 2 {
        questions.text! = "Have You Been Around People?"
            ageTextField.isHidden = true
            yesOrNo.isHidden = false
            favoriteDayTextField.isHidden = true
            AroundPeople.isHidden = true
            historyWithFlu1.isHidden = true
            highBloodPessure1.isHidden = true
            immuneSystem1.isHidden = true
            drugUse1.isHidden = true
            nextResults.setTitle("Next", for: .normal)
            firstBox = Bool(true)
            backResult2.setTitle("Back", for: .normal)
            
                }
        if questionPoint == 3 {
        questions.text! = "Do you wash your hands frequently?"
            
            ageTextField.isHidden = true
            yesOrNo.isHidden = true
            favoriteDayTextField.isHidden = true
            AroundPeople.isHidden = false
            historyWithFlu1.isHidden = true
            highBloodPessure1.isHidden = true
            immuneSystem1.isHidden = true
            drugUse1.isHidden = true
            firstBox = Bool(true)
            backResult2.setTitle("Back", for: .normal)
            nextResults.setTitle("Next", for: .normal)
           
                }
        
        if questionPoint == 4 {
        questions.text! =  "Have you been around people with the flu"
       
            ageTextField.isHidden = true
            yesOrNo.isHidden = true
            favoriteDayTextField.isHidden = true
            AroundPeople.isHidden = true
            historyWithFlu1.isHidden = false
            highBloodPessure1.isHidden = true
            immuneSystem1.isHidden = true
            drugUse1.isHidden = true
            firstBox = Bool(true)
            backResult2.setTitle("Back", for: .normal)
            nextResults.setTitle("Next", for: .normal)
                }
        if questionPoint == 5 {
        questions.text! = "Do you have a history with health problems? (Diabetes, High Blood Pressure, Cancer or Lung Disease)"
       
            
            ageTextField.isHidden = true
            yesOrNo.isHidden = true
            favoriteDayTextField.isHidden = true
            AroundPeople.isHidden = true
            historyWithFlu1.isHidden = true
            highBloodPessure1.isHidden = false
            immuneSystem1.isHidden = true
            drugUse1.isHidden = true
            firstBox = Bool(true)
            backResult2.setTitle("Back", for: .normal)
            nextResults.setTitle("Next", for: .normal)
                }
        if questionPoint == 6 {
        questions.text! =  "Have you been seeing symptoms? (Coughing, Fever, Sneezing, Lost sense of smell)"
            ageTextField.isHidden = true
            yesOrNo.isHidden = true
            favoriteDayTextField.isHidden = true
            AroundPeople.isHidden = true
            historyWithFlu1.isHidden = true
            highBloodPessure1.isHidden = true
            immuneSystem1.isHidden = false
            drugUse1.isHidden = true
            nextResults.setTitle("Next", for: .normal)
            firstBox = Bool(true)
            backResult2.setTitle("Back", for: .normal)
                        
                }
        if questionPoint == 7 {
        questions.text! =  "Have you been vaccinated?"
       
            ageTextField.isHidden = true
            yesOrNo.isHidden = true
            favoriteDayTextField.isHidden = true
            AroundPeople.isHidden = false
            historyWithFlu1.isHidden = true
            highBloodPessure1.isHidden = true
            immuneSystem1.isHidden = true
            drugUse1.isHidden = false
            firstBox = Bool(true)
            backResult2.setTitle("Back", for: .normal)
            nextResults.setTitle("Get Results", for: .normal)
            nextResults.isHidden = false
        }
        
        
    }
    

        
    //DATASETS LIKE COUNTIES AGE AND YES OR NO QUESTIONS
    
    let days = ["Allegany County", "Anne Arundel County", "Baltimore", "Baltimore County", "Calvert County", "Caroline County", "Carroll County", "Cecil County", "Charles County", "Dorchester County", "Fredrick County", "Harford County", "Howard County", "Kent County", "Montgomery County", "Prince George's County", "Queen Anne's County", "St. Mary's County", "Washington County", "Wicomico County", "Worchester County"]
           
    
    let days1 = ["3 - 12", "13 - 19", "20 - 34", "35 - 49", "50 - 64", "65 - 100"]
    
    let yesOrNo1 = ["Yes","No"]
    
    let yesOrNo2 = ["Yes","No"]
  
    
    let hwff = ["Yes","No"]
    
    let hbp = ["Yes","No"]
    
    let isi = ["Yes","No"]
    
    let dU = ["Yes","No"]
    
    
    
    //VARIABLES

    
    var countyPickerView = UIPickerView()
    var agePickerView = UIPickerView()
    var yesOrNoPickerView = UIPickerView()
    var AroundPeoplePickerView = UIPickerView()
    var hwfPickerView2 = UIPickerView()
    var hbpPickerView2 = UIPickerView()
    var isiPickerView2 = UIPickerView()
    var dUPickerView2 = UIPickerView()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        firstBox = Bool(false)

        
        if questionPoint == 0 {
        questions.text! = "Select County"
       
            firstBox = Bool(firstBox)
            print(firstBox)
            favoriteDayTextField.isHidden = false
            backResult2.isHidden = true
            backResult2.setTitle("", for: .normal)
       
            if favoriteDayTextField.text! == "Prince George's County" {
                
                firstBox = Bool(true)
            
           
                                                                           
                                                                       }
            if favoriteDayTextField.text! == "Montgomery County" {
                firstBox = Bool(true)
  
          
                                      
                                                
                                            }
            if favoriteDayTextField.text! == "Baltimore County" {
                firstBox = Bool(true)
      
                                                   
                                               }

            if favoriteDayTextField.text! == "Baltimore" {
                firstBox = Bool(true)
            
                                                                         
                                                                     }
            if favoriteDayTextField.text! == "Anne Arundel County" {
                firstBox = Bool(true)
         
                                                                         
                                                                     }
            if favoriteDayTextField.text! == "Allegany County" {
                firstBox = Bool(true)
         
                                                                         
                                                                     }
            if favoriteDayTextField.text! == "Howard County" {
                firstBox = Bool(true)

                                                                         
                                                                     }
            if favoriteDayTextField.text! == "Fredrick County" {
                firstBox = Bool(true)
           
                                              
                                                                 }
            if favoriteDayTextField.text! == "Charles County" {
                firstBox = Bool(true)
                                                                              }

            if favoriteDayTextField.text! == "Harford County" {
                firstBox = Bool(true)
         
      
                                                               }
            if favoriteDayTextField.text! == "Carroll County" {
                firstBox = Bool(true)
   
                                                   
                                                                   }
            if favoriteDayTextField.text! == "Wicomico County" {
                firstBox = Bool(true)
        
                                                       
                                                                       }
            if favoriteDayTextField.text! == "Washington County" {
                firstBox = Bool(true)
                                                                           }
            if favoriteDayTextField.text! == "St. Mary's County" {
                firstBox = Bool(true)
    
                                                                   
                                                                                   }
            if favoriteDayTextField.text! == "Cecil County" {
                firstBox = Bool(true)
                        
                                                                       }
            if favoriteDayTextField.text! == "Calvert County" {
                firstBox = Bool(true)
                                         
                                                                                     }
            if favoriteDayTextField.text! == "Caroline County" {
                firstBox = Bool(true)
                                              
                                                                                        }
            if favoriteDayTextField.text! == "Worchester County" {
                firstBox = Bool(true)
                                      
                                                                                               }
            if favoriteDayTextField.text! == "Queen Anne's County" {
                firstBox = Bool(true)
       
   
            }
                        
                }
        

        
        
     //CONNECTING TEXTFIELD TO PICKERVIEW
    
        favoriteDayTextField.inputView = countyPickerView
        ageTextField.inputView = agePickerView
        yesOrNo.inputView = yesOrNoPickerView
        AroundPeople.inputView = AroundPeoplePickerView
       
        
         historyWithFlu1.inputView = hwfPickerView2
             highBloodPessure1.inputView = hbpPickerView2
             immuneSystem1.inputView = isiPickerView2
             drugUse1.inputView = dUPickerView2
            

   

    
        //GET DATA FROM ITSELF
        
        
        countyPickerView.delegate = self
        countyPickerView.dataSource = self
        agePickerView.delegate = self
        agePickerView.dataSource = self
        yesOrNoPickerView.delegate = self
        AroundPeoplePickerView.delegate = self
        yesOrNoPickerView.dataSource = self
        AroundPeoplePickerView.dataSource = self
        
               hwfPickerView2.delegate = self
               hwfPickerView2.dataSource = self
               
               hbpPickerView2.delegate = self
               hbpPickerView2.dataSource = self
               
               isiPickerView2.delegate = self
               isiPickerView2.dataSource = self
               
               dUPickerView2.delegate = self
               dUPickerView2.dataSource = self
               

        //TAG NAMES
        
        countyPickerView.tag = 1
        agePickerView.tag = 2
        yesOrNoPickerView.tag = 3
        AroundPeoplePickerView.tag = 4
        hwfPickerView2.tag = 5
        hbpPickerView2.tag = 6
        isiPickerView2.tag = 7
        dUPickerView2.tag = 8
        
        createDayPicker()
          createToolbar()
      }
      func createDayPicker () {
        
        countyPickerView.backgroundColor = .systemTeal
        agePickerView.backgroundColor = .systemTeal
        yesOrNoPickerView.backgroundColor = .systemTeal
        AroundPeoplePickerView.backgroundColor = .systemTeal
        hwfPickerView2.backgroundColor = .systemTeal
        hbpPickerView2.backgroundColor = .systemTeal
        isiPickerView2.backgroundColor = .systemTeal
        dUPickerView2.backgroundColor = .systemTeal
      }
      

//COLOR TOOLBAR
  func createToolbar () {
      
      let toolBar = UIToolbar()
      toolBar.sizeToFit()

      toolBar.barTintColor = .black
      toolBar.tintColor = .white
      
      let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(MainViewController.dismissKeyboard))
      
      toolBar.setItems([doneButton], animated: false)
      toolBar.isUserInteractionEnabled = true
      
      favoriteDayTextField.inputAccessoryView = toolBar
      ageTextField.inputAccessoryView = toolBar
      yesOrNo.inputAccessoryView = toolBar
      AroundPeople.inputAccessoryView = toolBar
    historyWithFlu1.inputAccessoryView = toolBar
    highBloodPessure1.inputAccessoryView = toolBar
    immuneSystem1.inputAccessoryView = toolBar
    drugUse1.inputAccessoryView = toolBar
  }

      @objc func dismissKeyboard () {
          view.endEditing(true)
          
          
      
      }
        
        
    }



extension MainViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    //RETURN ONE DATASET
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        //GET THESE DATASETS
        
        switch pickerView.tag {
        case 1:
        
            return days.count
        
        case 2:
            
            return days1.count
            
        case 3:
        
            return yesOrNo1.count
        case 4:
        
            return yesOrNo2.count
        case 5:
        
        return hwff.count
        
        case 6:
            
            return hbp.count
            
        case 7:
        
            return isi.count
        case 8:
        
            return dU.count
        default:
            return 1
        }
    }
        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            //GET THESE DATASETS
          
            switch pickerView.tag {
             case 1:
        
                return days[row]
                
             case 2:
                 
                return days1[row]
                 
             case 3:
             
                return yesOrNo1[row]
            case 4:
            
                return yesOrNo2[row]
                
            case 5:
       
            return hwff[row]
               
            case 6:
                
                return hbp[row]
                
            case 7:
            
                return isi[row]
           case 8:
           
               return dU[row]
                
             default:
                 return "Data not found."
                 
             }
          
        }
 
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        //GET THESE DATASETS AND SHOW IT ON TEXTFIELD
//IF THIS IS SELECTED ADD TO PERCENTAGE
        switch pickerView.tag {
        case 1:
        
            favoriteDayTextField.text = days[row]
            favoriteDayTextField.resignFirstResponder()
            infoTrack.text = days[row]
            infoTrack.resignFirstResponder()
            
            if favoriteDayTextField.text! == "Prince George's County" {
                
                firstBox = Bool(true)
            
               percentage = Float(1.5)
            
                                                                           
                                                                       }
            if favoriteDayTextField.text! == "Montgomery County" {
                firstBox = Bool(true)
                percentage = Float(1.5)
          
                                      
                                                
                                            }
            if favoriteDayTextField.text! == "Baltimore County" {
                firstBox = Bool(true)
                percentage = Float(1.1)
      
                                                   
                                               }

            if favoriteDayTextField.text! == "Baltimore" {
                firstBox = Bool(true)
                percentage = Float(1.4)
            
                                                                         
                                                                     }
            if favoriteDayTextField.text! == "Anne Arundel County" {
                firstBox = Bool(true)
                percentage = Float(0.9)
         
                                                                         
                                                                     }
            if favoriteDayTextField.text! == "Allegany County" {
                firstBox = Bool(true)
                percentage = Float(0.9)
         
                                                                         
                                                                     }
            if favoriteDayTextField.text! == "Howard County" {
                firstBox = Bool(true)
            percentage = Float(0.9)

                                                                         
                                                                     }
            if favoriteDayTextField.text! == "Fredrick County" {
                firstBox = Bool(true)
                percentage = Float(1.0)
           
                                              
                                                                 }
            if favoriteDayTextField.text! == "Charles County" {
                firstBox = Bool(true)
                percentage = Float(0.9)
   
                                                                     }

            if favoriteDayTextField.text! == "Harford County" {
                firstBox = Bool(true)
                percentage = Float(0.5)
      
                                                               }
            if favoriteDayTextField.text! == "Carroll County" {
                firstBox = Bool(true)
                percentage = Float(0.7)
   
                                                   
                                                                   }
            if favoriteDayTextField.text! == "Wicomico County" {
                firstBox = Bool(true)
                percentage = Float(0.9)
        
                                                       
                                                                       }
            if favoriteDayTextField.text! == "Washington County" {
                firstBox = Bool(true)
                percentage = Float(0.9)
       
                                                                           }
            if favoriteDayTextField.text! == "St. Mary's County" {
                firstBox = Bool(true)
                percentage = Float(0.6)
    
                                                                   
                                                                                   }
            if favoriteDayTextField.text! == "Cecil County" {
                firstBox = Bool(true)
                percentage = Float(0.5)
                     
                                                                       }
            if favoriteDayTextField.text! == "Calvert County" {
                firstBox = Bool(true)
                percentage = Float(0.5)
                                         
                                                                                     }
            if favoriteDayTextField.text! == "Caroline County" {
                firstBox = Bool(true)
                percentage = Float(1.1)
                                              
                                                                                        }
            if favoriteDayTextField.text! == "Worchester County" {
                firstBox = Bool(true)
                percentage = Float(1.4)
                                    
                                                                                               }
            if favoriteDayTextField.text! == "Queen Anne's County" {
                firstBox = Bool(true)
                percentage = Float(0.6)
   
            }
        
            
        case 2:
            //IF THIS IS SELECTED ADD TO PERCENTAGE
            ageTextField.text = days1[row]
            ageTextField.resignFirstResponder()
            infoTrack1.text = days1[row]
            infoTrack1.resignFirstResponder()
            if ageTextField.text! == "65 - 100" {
                firstBox = Bool(true)
                age = Float(2.04)
            }
 
            if ageTextField.text! == "50 - 64" {
                firstBox = Bool(true)
               age = Float(1.52)
            }
            if ageTextField.text! == "35 - 49" {
                firstBox = Bool(true)
                age = Float(1.52)
            }
            if ageTextField.text! == "20 - 34" {
                firstBox = Bool(true)
                age = Float(1.52)
            }
            if ageTextField.text! == "13 - 19" {
                firstBox = Bool(true)
            age = Float(0.52)
            }
            if ageTextField.text! == "3 - 12" {
                firstBox = Bool(true)
                age = Float(0.52)
            }
            
        case 3:
            //IF THIS IS SELECTED ADD TO PERCENTAGE
            yesOrNo.text = yesOrNo1[row]
            yesOrNo.resignFirstResponder()
            introTrack2.text = yesOrNo1[row]
            introTrack2.resignFirstResponder()
            if yesOrNo.text! == "No" {
                firstBox = Bool(true)
                results = Float(0.0)
                
                //SET RESULTS AS 3
                No1 = Float(0.5)
            }
                if yesOrNo.text! == "Yes" {
                    firstBox = Bool(true)
                    results = Float(0.0)
                    
                    //SET RESULTS AS 3
                    No1 = Float(2.0)
                    
                    
                    
                }
            
                    
                    
            
        case 4:
            //IF THIS IS SELECTED ADD TO PERCENTAGE
            AroundPeople.text = yesOrNo2[row]
            AroundPeople.resignFirstResponder()
            introTrack3.text = yesOrNo2[row]
            introTrack3.resignFirstResponder()

            if AroundPeople.text! == "No" {
                firstBox = Bool(true)
                results = Float(0.0)
                
                //SET RESULTS AS 3
                Yes1 = Float(1.20)
            }
                if AroundPeople.text! == "Yes" {
                    firstBox = Bool(true)
                results = Float(0.0)
                    
                    //SET RESULTS AS 3
                    Yes1 = Float(0.60)
                    
                    
                    
                }
            
                       case 5:
                           
                           historyWithFlu1.text = hwff[row]
                           historyWithFlu1.resignFirstResponder()
                        introTrack4.text = hwff[row]
                        introTrack4.resignFirstResponder()
                        
                           if historyWithFlu1.text! == "No" {
                            firstBox = Bool(true)
                               
                               //SET RESULTS AS 3
                            hwf2 = Float(-50)
                            print(percentage)
                           }
                               if historyWithFlu1.text! == "Yes" {
                                firstBox = Bool(true)
                                   
                                   //SET RESULTS AS 3
                                   hwf = Float(50)
                                   
                                   
                                   
                               }

                       case 6:
                           
                           highBloodPessure1.text = hbp[row]
                           highBloodPessure1.resignFirstResponder()
                        introTrack5.text = hbp[row]
                        introTrack5.resignFirstResponder()
                           if highBloodPessure1.text! == "No" {
                            firstBox = Bool(true)
                               
                               //SET RESULTS AS 3
                               highBoodPress2 = Float(-30)
                           }
                               if highBloodPessure1.text! == "Yes" {
                                firstBox = Bool(true)
                                   
                                   //SET RESULTS AS 3
                                highBoodPress = Float(30)
                           
                                   
                                   
                               }

                       case 7:
                           
                           immuneSystem1.text = isi[row]
                           immuneSystem1.resignFirstResponder()
                        introTrack6.text = isi[row]
                        introTrack6.resignFirstResponder()
                           if immuneSystem1.text! == "No" {
                              
                            firstBox = Bool(true)
                               //SET RESULTS AS 3
                               immuneSys2 = Float(-80)
                           }
                               if immuneSystem1.text! == "Yes" {
                           
                                firstBox = Bool(true)
                                   //SET RESULTS AS 3
                                   immuneSys = Float (80)
                                   
                                
                                   
                               }

                       case 8:
                           
                           drugUse1.text = dU[row]
                           drugUse1.resignFirstResponder()
                        introTrack7.text = dU[row]
                        introTrack7.resignFirstResponder()
                           
                           if drugUse1.text! == "No" {
                              
                            firstBox = Bool(true)
                               //SET RESULTS AS 3
                               drugUsage = Float(40)
                           }
                               if drugUse1.text! == "Yes" {
                                firstBox = Bool(true)
                                   
                                   //SET RESULTS AS 3
                                   drugUsage2 = Float (-40)
                                   
                                   
                                   
                               }
        default:
            return
            
        
        
            }
    
    }
    
    
}
    
